---
description: L'Expert Métier spécialisé dans la logique métier, les besoins utilisateurs et la connaissance du domaine.
---

// turbo-all
1. Lancer l'Expert Métier : `view_file .agent/workflows/team/expert-metier.md`

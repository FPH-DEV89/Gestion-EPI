---
description: L'Expert IA / Data spécialisé dans le Prompt Engineering, les LLM et la structure des données.
---

// turbo-all
1. Lancer l'Expert IA / Data : `view_file .agent/workflows/team/ia.md`

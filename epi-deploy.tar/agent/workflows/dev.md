---
description: Lancement du serveur de développement
---

// turbo-all

Ce workflow démarre le projet Next.js en mode développement.

// turbo
1. Lancer le serveur de développement
```powershell
npm run dev
```
